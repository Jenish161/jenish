<?php
// Establish database connection

$servername = "192.168.40.8";
$username = "bca21171";
$password = "bca21171";
$dbname = "bca21171";;

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get the customer ID from the URL parameter
$customer_id = $_GET['id'];

// Delete customer from the database
$sql = "DELETE FROM customers WHERE id = $customer_id";

if ($conn->query($sql) === TRUE) {
  echo "Customer deleted successfully!";
} else {
  echo "Error deleting customer: " . $conn->error;
}

$conn->close();
?>
