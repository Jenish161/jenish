<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <title>Customer Login</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <h2>Customer Login</h2>
            <form action="" method="post">
                <div class="form-group">
                    <label for="pwd">Email:</label>
                    <input type="email"  class="form-control" name="email" placeholder="Email" required><br>
                </div>
                <div class="form-group">
                    <label for="pwd">Email:</label>
                    <input type="password" class="form-control" name="password" placeholder="Password" required><br>
                </div>

                <input type="submit"  class="btn btn-default" value="Login">
            </form>
            <p>Not registered? <a href="registration.php">Register here</a></p>
        </div>
    </body>
</html>
<?php
// Establish database connection

$servername = "192.168.40.8";
$username = "bca21171";
$password = "bca21171";
$dbname = "bca21171";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST['submit']) && isset($_POST['email'])) {
// Retrieve form data
    $email = $_POST['email'];
    $password = $_POST['password'];
}

// Check if the customer exists in the database
$sql = "SELECT * FROM customers WHERE email = '$email' AND password = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Customer exists, redirect to profile page
    header("Location: customer_detail.php");
} else {
    // Invalid credentials, show error message
    echo "Invalid email or password";
}

$conn->close();
?>
