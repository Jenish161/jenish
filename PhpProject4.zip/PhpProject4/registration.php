<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<!DOCTYPE html>
<html>
    <head>
        <title>Customer Registration</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <h2>Customer Registration</h2>
            <form action=".//registration.php" method="post">
                <div class="form-group">
                    <label for="pwd">First Name :</label>
                    <input type="text" class="form-control" name="first_name" placeholder="First Name" required>
                </div>
                <div class="form-group">
                    <label for="pwd">Last Name :</label>
                    <input type="text" class="form-control" name="last_name" placeholder="Last Name" required>
                </div>
                <div class="form-group">
                    <label for="pwd">Email :</label>
                    <input type="email" class="form-control" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <label for="pwd">Password :</label>
                    <input type="password" class="form-control" name="password" placeholder="Password" required>
                </div>
                <div class="form-group">
                    <label for="pwd">Address :</label>
                    <input type="text" class="form-control" name="address" placeholder="Address" required>
                </div>
                <div class="form-group">
                    <label for="pwd">City :</label>
                    <input type="text" class="form-control" name="city" placeholder="City" required>
                </div>
                <div class="form-group">
                    <label for="pwd">State:</label>
                    <input type="text"  class="form-control" name="state" placeholder="State" required>
                </div>
                <div class="form-group">
                    <label for="pwd">Postal code :</label>
                    <input type="text"  class="form-control" name="postal_code" placeholder="Postal Code" required>
                </div>
                <div class="form-group">
                    <input type="submit" value="Register">
                </div>
            </form>
            <p>Already registered? <a href="login.php">Login here</a></p>
        </div>
    </body>
</html>
<?php
// Establish database connection

$servername = "192.168.40.8";
$username = "bca21171";
$password = "bca21171";
$dbname = "bca21171";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$email = $_POST['email'];
$password = $_POST['password'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$postal_code = $_POST['postal_code'];

// Insert data into the database
$sql = "INSERT INTO customers (first_name, last_name, email, password, address, city, state, postal_code) 
        VALUES ('$first_name', '$last_name', '$email', '$password', '$address', '$city', '$state', '$postal_code')";

if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
