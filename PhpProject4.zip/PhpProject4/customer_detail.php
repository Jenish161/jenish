<!DOCTYPE html>
<html>
    <head>
        <title>Customer Details</title>
         <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

   <style>
table, td, th {
  border: 1px solid;
}

table {
  width: 100%;
  border-collapse: collapse;
}
</style>
    </head>
    <body>
        <div class="container">
        <h2>Customer Details</h2>
        <form action="" method="post">
              <div class="form-group">
                  <input type="text" class="form-control" name="search_query" placeholder="Search by ID, First Name, or Last Name">
                  <br>  <input type="submit" class="btn btn-default" value="Search">
              </div>
        </form>
        
            <h3>search</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Postal Code</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- Fetch and display all customers from the database -->
                <?php
                // Establish database connection

                $servername = "192.168.40.8";
                $username = "bca21171";
                $password = "bca21171";
                $dbname = "bca21171";
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $id=$_POST['search_query'];
                // Fetch all customers
                $sql = "SELECT * FROM customers where id=$id";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['first_name'] . "</td>";
                        echo "<td>" . $row['last_name'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>" . $row['address'] . "</td>";
                        echo "<td>" . $row['city'] . "</td>";
                        echo "<td>" . $row['state'] . "</td>";
                        echo "<td>" . $row['postal_code'] . "</td>";
                        echo "<td><a href='update_detail.php?id=" . $row['id'] . "'>Update</a> | <a href='delete_customer.php?id=" . $row['id'] . "'>Delete</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='9'>No customers found.</td></tr>";
                }

                
                $conn->close();
                ?>
            </tbody>
        </table>
        <h3>All Customers</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Postal Code</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- Fetch and display all customers from the database -->
                <?php
                // Establish database connection

                $servername = "192.168.40.8";
                $username = "bca21141";
                $password = "bca21141";
                $dbname = "bca21141";
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $id=$_POST['search_query'];
                // Fetch all customers
                $sql = "SELECT * FROM customers ";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['first_name'] . "</td>";
                        echo "<td>" . $row['last_name'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>" . $row['address'] . "</td>";
                        echo "<td>" . $row['city'] . "</td>";
                        echo "<td>" . $row['state'] . "</td>";
                        echo "<td>" . $row['postal_code'] . "</td>";
                        echo "<td><a href='update_customer.php?id=" . $row['id'] . "'>Update</a> | <a href='delete_customer.php?id=" . $row['id'] . "'>Delete</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='9'>No customers found.</td></tr>";
                }

                
                $conn->close();
                ?>
            </tbody>
        </table>
        </div>
    </body>
</html>
