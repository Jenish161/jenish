<!DOCTYPE html>
<html>
<head>
  <title>Update Profile</title>
 <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
  <h2>Update Profile</h2>
   <form action="login.php" method="post">
                <div class="form-group">
                    <label for="pwd">First Name :</label>
                    <input type="text" class="form-control" name="first_name" placeholder="First Name" required>
                </div>
                <div class="form-group">
                    <label for="pwd">Last Name :</label>
                    <input type="text" class="form-control" name="last_name" placeholder="Last Name" required>
                </div>
                <div class="form-group">
                    <label for="pwd">Email :</label>
                    <input type="email" class="form-control" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <label for="pwd">Password :</label>
                    <input type="password" class="form-control" name="password" placeholder="Password" required>
                </div>
                <div class="form-group">
                    <label for="pwd">Address :</label>
                    <input type="text" class="form-control" name="address" placeholder="Address" required>
                </div>
                <div class="form-group">
                    <label for="pwd">City :</label>
                    <input type="text" class="form-control" name="city" placeholder="City" required>
                </div>
                <div class="form-group">
                    <label for="pwd">State:</label>
                    <input type="text"  class="form-control" name="state" placeholder="State" required>
                </div>
                <div class="form-group">
                    <label for="pwd">Postal code :</label>
                    <input type="text"  class="form-control" name="postal_code" placeholder="Postal Code" required>
                </div>
    <input type="submit" value="Update">
  </form>
    </div>
</body>
</html>
<?php
// Establish database connection
$servername = "192.168.40.8";
$username = "bca21171";
$password = "bca21171";
$dbname = "bca21171";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$postal_code = $_POST['postal_code'];

// Update customer's profile in the database
$sql = "UPDATE customers SET first_name = '$first_name', last_name = '$last_name', address = '$address', city = '$city', state = '$state', postal_code = '$postal_code' WHERE id = $customer_id";

if ($conn->query($sql) === TRUE) {
  echo "Profile updated successfully!";
} else {
  echo "Error updating profile: " . $conn->error;
}

$conn->close();
?>

