<!DOCTYPE html>
<html>
<head>
  <title>Update Customer</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <h2>Update Customer</h2>
  <?php
  // Get the customer ID from the URL parameter
  $customer_id = $_GET['id'];

  // Fetch customer data from the database
  $sql = "SELECT * FROM customers WHERE id = $customer_id";
  $result = $conn->query($sql);

  if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();

    // Display the update form with pre-filled customer data
    echo '<form action="update_customer_process.php" method="post">';
    echo '<input type="hidden" name="customer_id" value="' . $customer_id . '">';
    echo '<input type="text" name="first_name" placeholder="First Name" value="' . $row['first_name'] . '" required><br>';
    echo '<input type="text" name="last_name" placeholder="Last Name" value="' . $row['last_name'] . '" required><br>';
    echo '<input type="text" name="address" placeholder="Address" value="' . $row['address'] . '" required><br>';
    echo '<input type="text" name="city" placeholder="City" value="' . $row['city'] . '" required><br>';
    echo '<input type="text" name="state" placeholder="State" value="' . $row['state'] . '" required><br>';
    echo '<input type="text" name="postal_code" placeholder="Postal Code" value="' . $row['postal_code'] . '" required><br>';
    echo '<input type="submit" value="Update">';
    echo '</form>';
  } else {
    echo "Customer not found.";
  }

  $conn->close();
  ?>
</body>
</html>
<?php
// Establish database connection

$servername = "192.168.40.8";
$username = "bca21171";
$password = "bca21171";
$dbname = "bca21171";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$customer_id = $_POST['customer_id'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$postal_code = $_POST['postal_code'];

// Update customer's profile in the database
$sql = "UPDATE customers SET first_name = '$first_name', last_name = '$last_name', address = '$address', city = '$city', state = '$state', postal_code = '$postal_code' WHERE id = $customer_id";

if ($conn->query($sql) === TRUE) {
  echo "Customer profile updated successfully!";
} else {
  echo "Error updating customer profile: " . $conn->error;
}

$conn->close();
?>
